/**
 * CT CLM Remote Detailing,
 * Copyright (C) 2007-2020 Customertimes Corp.
 * 3 Columbus Circle, 15th Floor, #1513
 * New York, NY 10019
 * mailto:support@customertimes.com
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */

import {LightningElement, track, api, wire} from 'lwc';
import {NavigationMixin} from 'lightning/navigation';
import getObjects from '@salesforce/apex/CustomActivityPicklist.getActivityNames';
import getFields from '@salesforce/apex/CustomActivityPicklist.getActivityRecordTypes';
import createActivity from '@salesforce/apex/CustomActivityPicklist.createLinkToActionActivity';
import getURL from '@salesforce/apex/CustomActivityPicklist.getURL';
import getIsRDEnabled from '@salesforce/apex/CustomActivityPicklist.getIsRDEnabled';
import Lack_Of_Permissions from '@salesforce/label/c.Lack_Of_Permissions';
import First_Step from '@salesforce/label/c.First_Step';
import Second_Step from '@salesforce/label/c.Second_Step';
import Third_Step from '@salesforce/label/c.Third_Step';
import Fourth_Step from '@salesforce/label/c.Fourth_Step';

export default class ActivityActionIndicator extends NavigationMixin(LightningElement) {
    First_Step = First_Step;
    Second_Step = Second_Step;
    Third_Step = Third_Step;
    Fourth_Step = Fourth_Step;

    @track objects = [];
    @track fields = [];
    @track step = '1';
    @track showActivityType = true;
    @track placeholderActivity = 'Select Activity';
    @track activity;
    @track labelRT = 'Select RT';
    @track activityId;
    @track recordType;
    @track isDisableActivity = false;
    @track isDisableRT = false;
    @track buttonValue = 'Next';
    @track message = First_Step + '...';
    @track errorMessage = '';
    @api recId;

    isProgressing = false;
    isError = false;

    @wire(getIsRDEnabled)
    checkingRDEnable({error, data}) {
        if (data === false) {
            this.showActivityType = false;
            this.isError = true;
            this.errorMessage = Lack_Of_Permissions;
        }
        else if (error) {
            this.error = error;
        }
    }

    toggleProgress() {
        this.isProgressing = !this.isProgressing;
    }

    nextSteps() {
        if (this.activity != null) {
            this.toggleProgress();
            this.showActivityType = false;
            this.step = '2';

            createActivity({
                activityType: this.activity,
                recId: this.recId,
                recordTypeId: this.recordType
            })
                .then(result => {
                    if (result['activity'] != null) {
                        this.activityId = result['activity'];

                        setTimeout(() => {
                            this.step = '3';
                            this.message = Second_Step + '...';
                        }, 2000);
                        setTimeout(() => {
                            this.linkRDNavigate();
                        }, 4000);
                    } else {
                        this.isError = true;
                        this.errorMessage = 'Error: \n' + result['error'];
                        this.toggleProgress();
                    }
                })
                .catch(error => {
                    this.error = error;
                    this.isError = true;
                    this.errorMessage = error;
                });
        }
    }

    linkRDNavigate() {
        this.step = '4';
        this.message = Third_Step + '...';

        setTimeout(() => {
            getURL({
                activityId: this.activityId,
                activityApiName: this.activity,
            })
                .then(result => {
                    if (result == null) {
                        this.linkRDNavigate();
                    } else {
                        this.toggleProgress();
                        window.open(
                            result,
                            '_blank'
                        );
                        this.closeQuickAction();
                    }
                })
                .catch(error => {
                    this.error = error;
                });
            this.showActivityType = false;
        }, 2000);
    }

    @wire(getObjects)
    wiredMethod({error, data}) {
        if (data) {
            this.dataArray = data;
            let tempArray = [];
            this.dataArray.forEach(function (element) {
                let option =
                    {
                        label: element.label,
                        value: element.name
                    };
                tempArray.push(option);
            });
            this.objects = tempArray;
            if (this.objects.length === 1) {
                this.activity = this.objects[0].value;
                this.placeholderActivity = this.objects[0].label;
                this.isDisableActivity = true;
                this.getRecordsTypes();
            }
        } else if (error) {
            this.error = error;
        }
    }

    // in future to redirect on Activity
    navigateToWebPage() {
        // Navigate to a URL
        this[NavigationMixin.Navigate]({
                type: 'standard__webPage',
                attributes: {
                    url: ''
                }
            },
            true
        );
    }

    closeQuickAction() {
        console.log('close')
        this.dispatchEvent(new CustomEvent('close'));
    }

    handleObjectChange(event) {
        this.activity = event.detail.value;
        this.getRecordsTypes();
    }

    getRecordsTypes() {
        console.log('this.activity ' + this.activity)
        getFields({objectName: this.activity})
            .then(result => {
                this.dataArray = result;
                let tempArray = [];
                this.dataArray.forEach(function (element) {
                    let option =
                        {
                            label: element.label,
                            value: element.name
                        };
                    tempArray.push(option);
                });
                this.fields = tempArray;
                if (this.fields.length === 0 || (this.fields.length === 1 && this.fields[0].label === 'Master')) {
                    this.labelRT = '--none--';
                    this.isDisableRT = true;
                }
            })
            .catch(error => {
                this.error = error;
            });
    }

    handleFieldChange(event) {
        this.recordType = event.detail.value;
    }
}